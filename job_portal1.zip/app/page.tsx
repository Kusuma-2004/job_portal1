import Link from "next/link"
import { Briefcase, MapPin, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function JobPortal() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-gray-900">
            JobFinder
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="font-medium text-gray-900">
              Find Jobs
            </Link>
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900">
              Companies
            </Link>
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900">
              Resources
            </Link>
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900">
              For Employers
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900 hidden md:block">
              Sign In
            </Link>
            <Button>Post a Job</Button>
          </div>
        </div>
      </header>

      <section className="bg-white py-12 border-b">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Find Your Dream Job Today</h1>
            <p className="text-xl text-gray-600">Browse thousands of job listings from top companies</p>
          </div>

          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm border p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input placeholder="Job title or keyword" className="pl-10" />
              </div>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="remote">Remote</SelectItem>
                  <SelectItem value="new-york">New York</SelectItem>
                  <SelectItem value="san-francisco">San Francisco</SelectItem>
                  <SelectItem value="london">London</SelectItem>
                  <SelectItem value="berlin">Berlin</SelectItem>
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tech">Technology</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="design">Design</SelectItem>
                  <SelectItem value="sales">Sales</SelectItem>
                  <SelectItem value="customer-service">Customer Service</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="mt-4 flex justify-end">
              <Button className="w-full md:w-auto">Search Jobs</Button>
            </div>
          </div>
        </div>
      </section>

      <main className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/4 space-y-6">
            <div className="bg-white p-6 rounded-lg border">
              <h2 className="font-semibold text-lg mb-4">Filters</h2>

              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Job Type</h3>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded text-primary" />
                      <span>Full-time</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded text-primary" />
                      <span>Part-time</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded text-primary" />
                      <span>Contract</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded text-primary" />
                      <span>Internship</span>
                    </label>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Experience Level</h3>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded text-primary" />
                      <span>Entry Level</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded text-primary" />
                      <span>Mid Level</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded text-primary" />
                      <span>Senior Level</span>
                    </label>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Salary Range</h3>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0-50k">$0 - $50k</SelectItem>
                      <SelectItem value="50k-100k">$50k - $100k</SelectItem>
                      <SelectItem value="100k-150k">$100k - $150k</SelectItem>
                      <SelectItem value="150k+">$150k+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>

          <div className="md:w-3/4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">Featured Jobs</h2>
              <Select defaultValue="newest">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="relevant">Most Relevant</SelectItem>
                  <SelectItem value="salary-high">Highest Salary</SelectItem>
                  <SelectItem value="salary-low">Lowest Salary</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-6">
              {jobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>

            <div className="mt-8 flex justify-center">
              <Button variant="outline" className="mr-2">
                Previous
              </Button>
              <Button variant="outline" className="mx-1">
                1
              </Button>
              <Button variant="outline" className="mx-1">
                2
              </Button>
              <Button variant="outline" className="mx-1">
                3
              </Button>
              <Button variant="outline" className="ml-2">
                Next
              </Button>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">JobFinder</h3>
              <p className="text-gray-400">Connecting talented professionals with amazing opportunities since 2023.</p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">For Job Seekers</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Browse Jobs
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Career Advice
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Resume Builder
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Salary Calculator
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">For Employers</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Post a Job
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Recruiting Solutions
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Resources
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>© 2023 JobFinder. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function JobCard({ job }) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="h-12 w-12 rounded bg-gray-100 flex items-center justify-center">
            <img
              src={job.companyLogo || `/placeholder.svg?height=48&width=48`}
              alt={`${job.company} logo`}
              className="h-8 w-8 object-contain"
            />
          </div>
          <div className="flex-1">
            <Link href={`/jobs/${job.id}`} className="text-lg font-semibold hover:underline">
              {job.title}
            </Link>
            <div className="text-gray-500">{job.company}</div>
            <div className="mt-2 flex flex-wrap gap-2">
              <div className="flex items-center text-sm text-gray-500">
                <MapPin className="mr-1 h-4 w-4" />
                {job.location}
              </div>
              <div className="flex items-center text-sm text-gray-500">
                <Briefcase className="mr-1 h-4 w-4" />
                {job.type}
              </div>
              {job.salary && <div className="text-sm text-gray-500">{job.salary}</div>}
            </div>
            <p className="mt-3 text-gray-600 line-clamp-2">{job.description}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {job.tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 px-6 py-3 flex justify-between items-center">
        <span className="text-sm text-gray-500">Posted {job.postedAt}</span>
        <Button variant="outline">Apply Now</Button>
      </CardFooter>
    </Card>
  )
}

const jobs = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechCorp",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "San Francisco, CA (Remote)",
    type: "Full-time",
    salary: "$120k - $150k",
    description:
      "We're looking for a Senior Frontend Developer to join our team. You'll be responsible for building user interfaces for our web applications using React and TypeScript.",
    tags: ["React", "TypeScript", "Next.js", "Tailwind CSS"],
    postedAt: "2 days ago",
  },
  {
    id: 2,
    title: "Product Designer",
    company: "DesignHub",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "New York, NY",
    type: "Full-time",
    salary: "$90k - $120k",
    description:
      "Join our design team to create beautiful and functional user experiences for our clients. You'll be working closely with our product and engineering teams.",
    tags: ["UI/UX", "Figma", "Product Design", "User Research"],
    postedAt: "3 days ago",
  },
  {
    id: 3,
    title: "Backend Engineer",
    company: "ServerStack",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "Remote",
    type: "Full-time",
    salary: "$130k - $160k",
    description:
      "We're seeking a Backend Engineer to help us build and scale our infrastructure. You'll be working with Node.js, PostgreSQL, and AWS.",
    tags: ["Node.js", "PostgreSQL", "AWS", "Microservices"],
    postedAt: "1 week ago",
  },
  {
    id: 4,
    title: "Marketing Manager",
    company: "GrowthCo",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "Chicago, IL",
    type: "Full-time",
    salary: "$80k - $100k",
    description:
      "We're looking for a Marketing Manager to lead our marketing efforts. You'll be responsible for developing and executing marketing strategies to drive growth.",
    tags: ["Digital Marketing", "SEO", "Content Strategy", "Analytics"],
    postedAt: "2 weeks ago",
  },
  {
    id: 5,
    title: "DevOps Engineer",
    company: "CloudTech",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "Remote",
    type: "Contract",
    salary: "$70 - $90 / hour",
    description:
      "Join our DevOps team to help us automate and optimize our infrastructure. You'll be working with Kubernetes, Docker, and CI/CD pipelines.",
    tags: ["Kubernetes", "Docker", "CI/CD", "AWS"],
    postedAt: "3 days ago",
  },
]

