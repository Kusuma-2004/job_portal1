import Link from "next/link"
import { ArrowLeft, Briefcase, Building, Clock, Globe, MapPin } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function JobDetails({ params }) {
  // In a real app, you would fetch the job details based on the ID
  const job = jobs.find((j) => j.id.toString() === params.id) || jobs[0]

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-gray-900">
            JobFinder
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="font-medium text-gray-900">
              Find Jobs
            </Link>
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900">
              Companies
            </Link>
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900">
              Resources
            </Link>
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900">
              For Employers
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="#" className="font-medium text-gray-500 hover:text-gray-900 hidden md:block">
              Sign In
            </Link>
            <Button>Post a Job</Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to jobs
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <Card>
              <CardHeader className="pb-4">
                <div className="flex items-start gap-4">
                  <div className="h-16 w-16 rounded bg-gray-100 flex items-center justify-center">
                    <img
                      src={job.companyLogo || `/placeholder.svg?height=64&width=64`}
                      alt={`${job.company} logo`}
                      className="h-10 w-10 object-contain"
                    />
                  </div>
                  <div>
                    <CardTitle className="text-2xl">{job.title}</CardTitle>
                    <CardDescription className="text-base">{job.company}</CardDescription>
                    <div className="mt-2 flex flex-wrap gap-4">
                      <div className="flex items-center text-sm text-gray-500">
                        <MapPin className="mr-1 h-4 w-4" />
                        {job.location}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Briefcase className="mr-1 h-4 w-4" />
                        {job.type}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="mr-1 h-4 w-4" />
                        Posted {job.postedAt}
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <Separator />
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Job Description</h3>
                    <p className="text-gray-700">{job.fullDescription || job.description}</p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-2">Responsibilities</h3>
                    <ul className="list-disc pl-5 space-y-2 text-gray-700">
                      {job.responsibilities?.map((item, i) => <li key={i}>{item}</li>) ||
                        defaultResponsibilities.map((item, i) => <li key={i}>{item}</li>)}
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-2">Requirements</h3>
                    <ul className="list-disc pl-5 space-y-2 text-gray-700">
                      {job.requirements?.map((item, i) => <li key={i}>{item}</li>) ||
                        defaultRequirements.map((item, i) => <li key={i}>{item}</li>)}
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-2">Benefits</h3>
                    <ul className="list-disc pl-5 space-y-2 text-gray-700">
                      {job.benefits?.map((item, i) => <li key={i}>{item}</li>) ||
                        defaultBenefits.map((item, i) => <li key={i}>{item}</li>)}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Similar Jobs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {similarJobs.map((job) => (
                    <div key={job.id} className="flex items-start gap-4 pb-4 border-b last:border-0 last:pb-0">
                      <div className="h-10 w-10 rounded bg-gray-100 flex items-center justify-center">
                        <img
                          src={job.companyLogo || `/placeholder.svg?height=40&width=40`}
                          alt={`${job.company} logo`}
                          className="h-6 w-6 object-contain"
                        />
                      </div>
                      <div className="flex-1">
                        <Link href={`/jobs/${job.id}`} className="font-medium hover:underline">
                          {job.title}
                        </Link>
                        <div className="text-sm text-gray-500">{job.company}</div>
                        <div className="mt-1 flex flex-wrap gap-2 text-xs text-gray-500">
                          <span>{job.location}</span>
                          <span>•</span>
                          <span>{job.type}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Apply for this job</CardTitle>
              </CardHeader>
              <CardContent>
                <Button className="w-full mb-4">Apply Now</Button>
                <Button variant="outline" className="w-full">
                  Save Job
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>About {job.company}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  {job.companyDescription ||
                    `${job.company} is a leading company in the ${job.tags[0]} industry, focused on delivering exceptional products and services to clients worldwide.`}
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Building className="h-4 w-4 text-gray-500" />
                    <span>50-200 employees</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Globe className="h-4 w-4 text-gray-500" />
                    <a href="#" className="text-primary hover:underline">
                      Visit website
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Job Details</CardTitle>
              </CardHeader>
              <CardContent>
                <dl className="space-y-4">
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Job Type</dt>
                    <dd className="mt-1">{job.type}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Salary Range</dt>
                    <dd className="mt-1">{job.salary}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Location</dt>
                    <dd className="mt-1">{job.location}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Required Skills</dt>
                    <dd className="mt-1">
                      <div className="flex flex-wrap gap-2">
                        {job.tags.map((tag) => (
                          <span
                            key={tag}
                            className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </dd>
                  </div>
                </dl>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="bg-gray-900 text-white py-12 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">JobFinder</h3>
              <p className="text-gray-400">Connecting talented professionals with amazing opportunities since 2023.</p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">For Job Seekers</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Browse Jobs
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Career Advice
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Resume Builder
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Salary Calculator
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">For Employers</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Post a Job
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Recruiting Solutions
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Resources
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>© 2023 JobFinder. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

const jobs = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechCorp",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "San Francisco, CA (Remote)",
    type: "Full-time",
    salary: "$120k - $150k",
    description:
      "We're looking for a Senior Frontend Developer to join our team. You'll be responsible for building user interfaces for our web applications using React and TypeScript.",
    fullDescription:
      "TechCorp is seeking an experienced Senior Frontend Developer to join our growing team. In this role, you'll be responsible for building and maintaining high-quality user interfaces for our web applications. You'll work closely with our design and backend teams to create seamless user experiences that delight our customers. The ideal candidate has a strong background in modern frontend technologies, particularly React and TypeScript, and a passion for creating clean, maintainable code.",
    tags: ["React", "TypeScript", "Next.js", "Tailwind CSS"],
    postedAt: "2 days ago",
  },
  {
    id: 2,
    title: "Product Designer",
    company: "DesignHub",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "New York, NY",
    type: "Full-time",
    salary: "$90k - $120k",
    description:
      "Join our design team to create beautiful and functional user experiences for our clients. You'll be working closely with our product and engineering teams.",
    tags: ["UI/UX", "Figma", "Product Design", "User Research"],
    postedAt: "3 days ago",
  },
  {
    id: 3,
    title: "Backend Engineer",
    company: "ServerStack",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "Remote",
    type: "Full-time",
    salary: "$130k - $160k",
    description:
      "We're seeking a Backend Engineer to help us build and scale our infrastructure. You'll be working with Node.js, PostgreSQL, and AWS.",
    tags: ["Node.js", "PostgreSQL", "AWS", "Microservices"],
    postedAt: "1 week ago",
  },
  {
    id: 4,
    title: "Marketing Manager",
    company: "GrowthCo",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "Chicago, IL",
    type: "Full-time",
    salary: "$80k - $100k",
    description:
      "We're looking for a Marketing Manager to lead our marketing efforts. You'll be responsible for developing and executing marketing strategies to drive growth.",
    tags: ["Digital Marketing", "SEO", "Content Strategy", "Analytics"],
    postedAt: "2 weeks ago",
  },
  {
    id: 5,
    title: "DevOps Engineer",
    company: "CloudTech",
    companyLogo: "/placeholder.svg?height=48&width=48",
    location: "Remote",
    type: "Contract",
    salary: "$70 - $90 / hour",
    description:
      "Join our DevOps team to help us automate and optimize our infrastructure. You'll be working with Kubernetes, Docker, and CI/CD pipelines.",
    tags: ["Kubernetes", "Docker", "CI/CD", "AWS"],
    postedAt: "3 days ago",
  },
]

const similarJobs = [
  {
    id: 6,
    title: "Frontend Developer",
    company: "WebSolutions",
    companyLogo: "/placeholder.svg?height=40&width=40",
    location: "Remote",
    type: "Full-time",
  },
  {
    id: 7,
    title: "UI Developer",
    company: "DigitalCraft",
    companyLogo: "/placeholder.svg?height=40&width=40",
    location: "Austin, TX",
    type: "Full-time",
  },
  {
    id: 8,
    title: "React Engineer",
    company: "AppWorks",
    companyLogo: "/placeholder.svg?height=40&width=40",
    location: "San Francisco, CA",
    type: "Contract",
  },
]

const defaultResponsibilities = [
  "Design, develop, and maintain frontend applications using React, TypeScript, and related technologies",
  "Collaborate with UX/UI designers to implement responsive and intuitive user interfaces",
  "Work with backend developers to integrate frontend applications with APIs and services",
  "Optimize applications for maximum speed and scalability",
  "Implement automated testing to ensure code quality and reliability",
  "Participate in code reviews and contribute to technical documentation",
]

const defaultRequirements = [
  "5+ years of experience in frontend development",
  "Strong proficiency in JavaScript, TypeScript, React, and modern frontend frameworks",
  "Experience with responsive design and cross-browser compatibility",
  "Familiarity with RESTful APIs and modern frontend build pipelines",
  "Strong problem-solving skills and attention to detail",
  "Excellent communication and collaboration skills",
  "Bachelor's degree in Computer Science or related field (or equivalent experience)",
]

const defaultBenefits = [
  "Competitive salary and equity package",
  "Comprehensive health, dental, and vision insurance",
  "Flexible work hours and remote work options",
  "Generous paid time off and parental leave",
  "401(k) matching program",
  "Professional development budget",
  "Regular team events and activities",
]

